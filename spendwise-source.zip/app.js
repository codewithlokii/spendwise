"use strict";

/* =========================================================
   SpendWise - app.js (Production Hardened Release - M5)
   Features:
   - Tenant-isolated persistence layer
   - Zero-drift integer paise quantization
   - Deterministic SHA-256 transaction deduplication
   - Automated keyword-based category classifier
   - RFC-4180 Quote-Aware CSV Ingestion Pipeline (Expense & Income)
   - Reactive chart rendering and memory cleanup
   ========================================================= */

// Categories Catalog
const CATEGORIES = [
  { id: "food",          name: "Food & Dining",  color: "#e6c15a" },
  { id: "travel",        name: "Travel & Fuel",  color: "#5fa8d3" },
  { id: "shopping",      name: "Shopping",       color: "#c78bd9" },
  { id: "bills",         name: "Bills & Utility",color: "#ef8a6b" },
  { id: "entertainment", name: "Entertainment",  color: "#6fd1b1" },
  { id: "health",        name: "Health & Care",  color: "#ef6b8a" },
  { id: "education",     name: "Education",      color: "#8fa0f0" },
  { id: "other",         name: "Other",          color: "#9aa4b5" }
];

const INCOME_CAT = { id: "income", name: "Income", color: "#5fc9a0" };
const WARN_RATIO = 0.8;

const KEYS = {
  users: "spendwise_secure_users",
  session: "spendwise_active_session",
  tenantPrefix: "spendwise_tenant_"
};

const DEMO = { id: "demo-tenant-student", name: "Demo Student", email: "student@spendwise.app", password: "DemoPassword123" };

// Global Application State
const state = {
  user: null,
  data: { transactions: [], budgets: {}, goals: [] },
  month: "",
  view: "dashboard",
  editingId: null,
  entryType: "expense",
  charts: {}
};

/* ---------------------------------------------------------
   UTILITY HELPERS
   --------------------------------------------------------- */
const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const pad = n => String(n).padStart(2, "0");

const moneyFormat = new Intl.NumberFormat("en-IN", {
  style: "currency", currency: "INR",
  minimumFractionDigits: 0, maximumFractionDigits: 2
});

const fmt = n => moneyFormat.format(n);
const fmtPaise = paise => moneyFormat.format(paise / 100);

function esc(text) {
  return String(text || "").replace(/[&<>"']/g, ch => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]
  ));
}

function uid() {
  return "tx_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function toISO(date) {
  return date.getFullYear() + "-" + pad(date.getMonth() + 1) + "-" + pad(date.getDate());
}
const todayISO = () => toISO(new Date());
const monthKeyOf = date => date.getFullYear() + "-" + pad(date.getMonth() + 1);

function parseISO(iso) {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d);
}

function isValidDate(iso) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return false;
  const d = parseISO(iso);
  return toISO(d) === iso;
}

function formatDate(iso) {
  return parseISO(iso).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}

function formatMonth(key, short = false) {
  const [y, m] = key.split("-").map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString("en-IN",
    short ? { month: "short" } : { month: "long", year: "numeric" });
}

function shiftMonth(key, delta) {
  const [y, m] = key.split("-").map(Number);
  return monthKeyOf(new Date(y, m - 1 + delta, 1));
}

const categoryById = id => id === "income" ? INCOME_CAT : (CATEGORIES.find(c => c.id === id) || CATEGORIES[CATEGORIES.length - 1]);
const isInc = t => t.type === "income";

function toast(message, type = "info") {
  const stack = $("#toast-stack");
  if (!stack) return;
  const el = document.createElement("div");
  el.className = "toast " + type;
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => el.remove(), 4200);
}

/* ---------------------------------------------------------
   HEURISTIC AUTO-CATEGORIZATION ENGINE
   --------------------------------------------------------- */
const CATEGORIZATION_RULES = [
  { pattern: /swiggy|zomato|canteen|cafe|restaurant|mcdonald|food|tea|chai|dinner|lunch|pizza|burger|grocery|supermarket/i, category: "food" },
  { pattern: /uber|ola|metro|fuel|petrol|diesel|auto|rapido|bus|train|irctc|flight|cab/i, category: "travel" },
  { pattern: /amazon|flipkart|myntra|zara|h&m|clothing|shoes|mall|store|apparel|electronics/i, category: "shopping" },
  { pattern: /electricity|wifi|broadband|recharge|airtel|jio|vi|bill|water|cylinder|hostel electricity/i, category: "bills" },
  { pattern: /netflix|spotify|prime|cinema|movie|theatre|steam|gaming|hotstar|pvr/i, category: "entertainment" },
  { pattern: /pharmacy|apollo|hospital|doctor|gym|cult|fitness|meds|medicine|1mg/i, category: "health" },
  { pattern: /coursera|udemy|books|tuition|college|exam|stationery|printout|photocopy|lab manual|notes/i, category: "education" }
];

function classifyDescription(text) {
  if (!text) return "other";
  for (const rule of CATEGORIZATION_RULES) {
    if (rule.pattern.test(text)) return rule.category;
  }
  return "other";
}

/* ---------------------------------------------------------
   SECURITY & TENANT-ISOLATED STORAGE ENGINE
   --------------------------------------------------------- */
async function computeHash(password, email) {
  const text = email.trim().toLowerCase() + "::spendwise_salt::" + password;
  const bytes = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, "0")).join("");
}

async function computeFingerprint(tenantId, tx) {
  const payload = `${tenantId}#${tx.date}#${tx.amountInPaise}#${(tx.note || "").trim().toLowerCase()}`;
  const bytes = new TextEncoder().encode(payload);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, "0")).join("");
}

function loadJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (err) {
    return fallback;
  }
}

function saveJSON(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    toast("Storage quota exceeded or browser restriction.", "error");
  }
}

const getUsers = () => loadJSON(KEYS.users, []);
const getTenantStorageKey = tenantId => KEYS.tenantPrefix + tenantId;

function saveTenantData() {
  if (!state.user) return;
  saveJSON(getTenantStorageKey(state.user.id), state.data);
}

function loadTenantData(tenantId) {
  const fallback = { transactions: [], budgets: {}, goals: [] };
  const loaded = loadJSON(getTenantStorageKey(tenantId), fallback);
  loaded.transactions = loaded.transactions || [];
  loaded.budgets = loaded.budgets || {};
  loaded.goals = loaded.goals || [];
  return loaded;
}

/* ---------------------------------------------------------
   AUTH & SESSION (FR1)
   --------------------------------------------------------- */
function switchAuthTab(name) {
  $$(".tab").forEach(tab => {
    const active = tab.dataset.tab === name;
    tab.classList.toggle("active", active);
    tab.setAttribute("aria-selected", String(active));
  });
  $("#login-form").hidden = name !== "login";
  $("#register-form").hidden = name !== "register";
  $("#login-error").textContent = "";
  $("#register-error").textContent = "";
}

async function onRegister(e) {
  e.preventDefault();
  const name = $("#reg-name").value.trim();
  const email = $("#reg-email").value.trim().toLowerCase();
  const password = $("#reg-password").value;
  const errorBox = $("#register-error");

  if (!name) return void (errorBox.textContent = "Please enter your name.");
  if (!/^\S+@\S+\.\S+$/.test(email)) return void (errorBox.textContent = "Enter a valid email address.");
  if (password.length < 6) return void (errorBox.textContent = "Password must be at least 6 characters.");

  const users = getUsers();
  if (users.some(u => u.email === email)) {
    return void (errorBox.textContent = "An account with this email already exists.");
  }

  const user = { id: "usr_" + uid(), name, email, passwordHash: await computeHash(password, email) };
  users.push(user);
  saveJSON(KEYS.users, users);

  $("#register-form").reset();
  startSession(user);
  toast("Account created successfully.", "success");
}

async function onLogin(e) {
  e.preventDefault();
  const email = $("#login-email").value.trim().toLowerCase();
  const password = $("#login-password").value;
  const errorBox = $("#login-error");

  if (!email || !password) return void (errorBox.textContent = "Enter both email and password.");

  const user = getUsers().find(u => u.email === email);
  const hash = await computeHash(password, email);

  if (!user || user.passwordHash !== hash) {
    return void (errorBox.textContent = "Invalid email or credentials.");
  }

  $("#login-form").reset();
  startSession(user);
}

async function onDemo() {
  const users = getUsers();
  let demo = users.find(u => u.id === DEMO.id);

  if (!demo) {
    demo = {
      id: DEMO.id, name: DEMO.name, email: DEMO.email,
      passwordHash: await computeHash(DEMO.password, DEMO.email)
    };
    users.push(demo);
    saveJSON(KEYS.users, users);
    saveJSON(getTenantStorageKey(demo.id), generateSampleData(demo.id));
  }

  startSession(demo);
}

function startSession(user) {
  saveJSON(KEYS.session, user.id);
  state.user = user;
  state.data = loadTenantData(user.id);
  state.month = monthKeyOf(new Date());
  state.view = "dashboard";

  $("#auth-view").hidden = true;
  $("#app-view").hidden = false;
  $("#user-name").textContent = user.name;
  $("#user-avatar").textContent = user.name.charAt(0).toUpperCase();

  showView("dashboard");
  window.scrollTo(0, 0);
}

function logout() {
  localStorage.removeItem(KEYS.session);
  Object.values(state.charts).forEach(c => c && c.destroy());
  state.charts = {};
  state.user = null;
  state.data = { transactions: [], budgets: {}, goals: [] };
  $("#app-view").hidden = true;
  $("#auth-view").hidden = false;
  switchAuthTab("login");
}

/* ---------------------------------------------------------
   TRANSACTION & BUDGET MATHEMATICS (Zero Floating Drift)
   --------------------------------------------------------- */
const expensesInMonth = month => state.data.transactions.filter(t => !isInc(t) && t.date.startsWith(month));
const incomeInMonth = month => state.data.transactions.filter(t => isInc(t) && t.date.startsWith(month));
const entriesInMonth = month => state.data.transactions.filter(t => t.date.startsWith(month));
const sumPaise = list => list.reduce((acc, t) => acc + (t.amountInPaise || 0), 0);

function totalsByCategory(list) {
  const totals = {};
  list.forEach(t => { totals[t.category] = (totals[t.category] || 0) + t.amountInPaise; });
  return CATEGORIES
    .map(c => ({ ...c, totalPaise: totals[c.id] || 0 }))
    .filter(c => c.totalPaise > 0)
    .sort((a, b) => b.totalPaise - a.totalPaise);
}

function getBudget(month) {
  const budgets = state.data.budgets;
  if (budgets[month] != null) return { limitPaise: budgets[month], carried: false };
  const earlier = Object.keys(budgets).filter(k => k < month).sort().pop();
  return earlier ? { limitPaise: budgets[earlier], carried: true } : null;
}

function budgetStatus(spentPaise, budget) {
  if (!budget) return { level: "none", ratio: 0 };
  const ratio = spentPaise / budget.limitPaise;
  const level = ratio >= 1 ? "over" : ratio >= WARN_RATIO ? "warn" : "ok";
  return { level, ratio };
}

const monthLevel = month => budgetStatus(sumPaise(expensesInMonth(month)), getBudget(month)).level;

/* ---------------------------------------------------------
   TRANSACTION CRUD MODULE (FR2, FR3)
   --------------------------------------------------------- */
const modal = () => $("#expense-modal");

function openExpenseModal(id = null) {
  state.editingId = id;
  $("#expense-form").reset();
  $$(".field-error").forEach(el => (el.textContent = ""));
  $("#expense-date").max = todayISO();

  if (id) {
    const tx = state.data.transactions.find(x => x.id === id);
    if (!tx) return;
    $("#modal-title").textContent = "Edit Transaction";
    $("#modal-save").textContent = "Save Changes";
    $("#expense-amount").value = (tx.amountInPaise / 100).toFixed(2);
    $("#expense-category").value = tx.category;
    $("#expense-date").value = tx.date;
    $("#expense-note").value = tx.note || "";
    setEntryType(tx.type);
  } else {
    $("#modal-title").textContent = "Record Transaction";
    $("#modal-save").textContent = "Save Transaction";
    $("#expense-category").value = "food";
    $("#expense-date").value = todayISO();
    setEntryType("expense");
  }

  modal().showModal();
  $("#expense-amount").focus();
}

function setEntryType(type) {
  state.entryType = type;
  $$(".seg-btn").forEach(b => b.classList.toggle("active", b.dataset.type === type));
  $("#category-field").hidden = type === "income";
  $("#modal-title").textContent = (state.editingId ? "Edit " : "Record ") + (type === "income" ? "Income" : "Expense");
  $("#modal-save").textContent = state.editingId ? "Save Changes" : "Save " + (type === "income" ? "Income" : "Expense");
}

function closeExpenseModal() {
  modal().close();
}

$("#expense-note").addEventListener("input", (e) => {
  if (state.entryType === "expense" && (!$("#expense-category").value || $("#expense-category").value === "other")) {
    const inferred = classifyDescription(e.target.value);
    if (inferred !== "other") {
      $("#expense-category").value = inferred;
    }
  }
});

async function onSaveExpense(e) {
  e.preventDefault();

  const rawAmount = parseFloat($("#expense-amount").value);
  let category = $("#expense-category").value;
  const date = $("#expense-date").value;
  const note = $("#expense-note").value.trim();

  let ok = true;
  const setErr = (id, msg) => { $("#err-" + id).textContent = msg; if (msg) ok = false; };

  setErr("amount", !(rawAmount > 0) ? "Enter an amount greater than 0." : "");
  setErr("date", !isValidDate(date) ? "Enter a valid date." : date > todayISO() ? "Cannot record future dates." : "");

  if (!ok) return;

  const isIncome = state.entryType === "income";
  if (!isIncome && (!category || category === "other")) {
    category = classifyDescription(note);
  }

  const amountInPaise = Math.round(rawAmount * 100);
  const month = date.slice(0, 7);
  const levelBefore = monthLevel(month);

  const entry = {
    amountInPaise,
    category: isIncome ? "income" : category,
    date,
    note,
    type: isIncome ? "income" : "expense"
  };

  const fingerprint = await computeFingerprint(state.user.id, entry);
  entry.fingerprint = fingerprint;

  if (state.editingId) {
    const idx = state.data.transactions.findIndex(x => x.id === state.editingId);
    if (idx !== -1) {
      state.data.transactions[idx] = { ...state.data.transactions[idx], ...entry, id: state.editingId };
    }
  } else {
    const duplicate = state.data.transactions.some(tx => tx.fingerprint === fingerprint);
    if (duplicate) {
      toast("Duplicate transaction detected with identical date, amount, and note.", "warn");
      return;
    }
    state.data.transactions.push({ id: uid(), ...entry });
  }

  saveTenantData();
  closeExpenseModal();
  renderCurrentView();

  toast((isIncome ? "Income" : "Expense") + (state.editingId ? " updated." : " saved."), "success");

  const levelAfter = monthLevel(month);
  if (levelAfter !== levelBefore) {
    const b = getBudget(month);
    const spentPaise = sumPaise(expensesInMonth(month));
    if (levelAfter === "warn") {
      toast("Alert: You have reached " + Math.round(spentPaise / b.limitPaise * 100) + "% of your " + formatMonth(month) + " budget.", "warn");
    } else if (levelAfter === "over") {
      toast("Budget Exceeded: Over limit by " + fmtPaise(spentPaise - b.limitPaise) + ".", "error");
    }
  }
}

function deleteExpense(id) {
  const tx = state.data.transactions.find(x => x.id === id);
  if (!tx) return;
  const label = (tx.note || categoryById(tx.category).name) + " (" + fmtPaise(tx.amountInPaise) + ")";
  if (!confirm("Are you sure you want to delete this transaction?\n" + label)) return;

  state.data.transactions = state.data.transactions.filter(x => x.id !== id);
  saveTenantData();
  renderCurrentView();
  toast("Transaction deleted.", "info");
}

const actionButtons = id =>
  '<div class="row-actions">' +
    '<button type="button" data-action="edit" data-id="' + id + '">Edit</button>' +
    '<button type="button" class="del" data-action="delete" data-id="' + id + '">Delete</button>' +
  '</div>';

/* ---------------------------------------------------------
   CSV INGESTION PIPELINE (RFC-4180 PARSER & DEDUPLICATION)
   --------------------------------------------------------- */
function parseCSVLine(line) {
  return line
    .split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/)
    .map(c => c.trim().replace(/^"|"$/g, "").replace(/""/g, '"'));
}

async function processCSVFile(file) {
  const text = await file.text();
  const lines = text.trim().split(/\r?\n/);
  if (lines.length < 2) {
    toast("CSV file must contain a header and transaction records.", "error");
    return;
  }

  const header = parseCSVLine(lines[0]).map(h => h.toLowerCase());
  const dateIdx = header.findIndex(h => h.includes("date"));
  const amountIdx = header.findIndex(h => h.includes("amount"));
  const noteIdx = header.findIndex(h => h.includes("note") || h.includes("desc") || h.includes("payee"));
  const catIdx = header.findIndex(h => h.includes("category"));
  const typeIdx = header.findIndex(h => h.includes("type"));

  if (dateIdx === -1 || amountIdx === -1) {
    toast("CSV schema must include 'Date' and 'Amount' columns.", "error");
    return;
  }

  let imported = 0, duplicates = 0, errors = 0;

  for (let i = 1; i < lines.length; i++) {
    const rawLine = lines[i].trim();
    if (!rawLine) continue;
    const cols = parseCSVLine(rawLine);

    const date = cols[dateIdx];
    const amountVal = parseFloat(cols[amountIdx]);
    const note = noteIdx !== -1 ? (cols[noteIdx] || "") : "";
    const rawCat = catIdx !== -1 && cols[catIdx] ? cols[catIdx].toLowerCase() : "";
    const rawType = typeIdx !== -1 && cols[typeIdx] ? cols[typeIdx].toLowerCase() : "";

    if (!isValidDate(date) || isNaN(amountVal) || amountVal === 0) {
      errors++;
      continue;
    }

    const isIncomeRow =
      rawType === "income" ||
      rawCat === "income" ||
      /\b(salary|stipend|freelance|allowance|refund|dividend|bonus|cashback)\b/i.test(note);

    const type = isIncomeRow ? "income" : "expense";
    const absVal = Math.abs(amountVal);
    const amountInPaise = Math.round(absVal * 100);

    let category;
    if (isIncomeRow) {
      category = "income";
    } else {
      const matchedCat = CATEGORIES.find(
        c => c.id === rawCat || c.name.toLowerCase() === rawCat
      );
      category = matchedCat ? matchedCat.id : classifyDescription(note);
    }

    const entry = {
      id: uid(),
      amountInPaise,
      category,
      date,
      note,
      type
    };

    const fingerprint = await computeFingerprint(state.user.id, entry);
    entry.fingerprint = fingerprint;

    if (state.data.transactions.some(tx => tx.fingerprint === fingerprint)) {
      duplicates++;
      continue;
    }

    state.data.transactions.push(entry);
    imported++;
  }

  saveTenantData();
  renderCurrentView();

  const reportBox = $("#import-report");
  const listEl = $("#import-summary-list");
  reportBox.hidden = false;
  listEl.innerHTML = `
    <li><span class="name">Successfully Ingested</span><span class="amt">${imported}</span></li>
    <li><span class="name">Duplicate Records Dropped</span><span class="amt">${duplicates}</span></li>
    <li><span class="name">Malformed Rows Skipped</span><span class="amt">${errors}</span></li>
  `;

  toast(`Ingestion complete: ${imported} imported, ${duplicates} duplicates skipped.`, "success");
}

/* ---------------------------------------------------------
   DASHBOARD & VIEW RENDERING
   --------------------------------------------------------- */
const VIEW_TITLES = { dashboard: "Dashboard", history: "History", reports: "Reports", budget: "Budget", goals: "Goals", import: "CSV Ingestion" };

function showView(name) {
  state.view = name;
  $$(".view").forEach(v => (v.hidden = v.id !== "view-" + name));
  $$(".nav-btn").forEach(b => b.classList.toggle("active", b.dataset.view === name));
  renderCurrentView();
  window.scrollTo(0, 0);
}

function renderCurrentView() {
  const hr = new Date().getHours();
  const greeting = hr < 12 ? "Good morning" : hr < 17 ? "Good afternoon" : "Good evening";
  $("#page-title").textContent = state.view === "dashboard" && state.user ? `${greeting}, ${state.user.name.split(" ")[0]}` : VIEW_TITLES[state.view];
  $("#month-label").textContent = formatMonth(state.month);
  $("#month-nav").hidden = (state.view === "history" || state.view === "goals" || state.view === "import");
  $("#next-month").disabled = state.month >= monthKeyOf(new Date());

  if (state.view === "dashboard") renderDashboard();
  if (state.view === "history") renderHistory();
  if (state.view === "reports") renderReports();
  if (state.view === "budget") renderBudget();
  if (state.view === "goals") renderGoals();
}

function drawChart(key, canvasId, fallbackId, config) {
  const fallback = $("#" + fallbackId);
  const canvas = $("#" + canvasId);
  if (state.charts[key]) {
    state.charts[key].destroy();
    state.charts[key] = null;
  }

  if (typeof Chart === "undefined") {
    if (canvas && canvas.parentElement) canvas.parentElement.hidden = true;
    if (fallback) fallback.hidden = false;
    return;
  }
  if (canvas && canvas.parentElement) canvas.parentElement.hidden = false;
  if (fallback) fallback.hidden = true;
  state.charts[key] = new Chart(canvas, config);
}

function setChartDefaults() {
  if (typeof Chart === "undefined") return;
  Chart.defaults.color = "#8e98ab";
  Chart.defaults.font.family = '"Space Grotesk", system-ui, sans-serif';
  Chart.defaults.borderColor = "rgba(255,255,255,0.07)";
}

/* ---------- Dashboard ---------- */
function renderDashboard() {
  const list = expensesInMonth(state.month);
  const spentPaise = sumPaise(list);
  const earnedPaise = sumPaise(incomeInMonth(state.month));
  const budget = getBudget(state.month);
  const status = budgetStatus(spentPaise, budget);

  $("#hero-label").textContent = "Spent in " + formatMonth(state.month);
  $("#hero-spent").textContent = fmtPaise(spentPaise);
  $("#stat-count").textContent = list.length;
  $("#stat-income").textContent = earnedPaise ? fmtPaise(earnedPaise) : "-";

  const savedPaise = earnedPaise - spentPaise;
  $("#stat-saved-label").textContent = savedPaise < 0 ? "Deficit" : "Net Saved";
  $("#stat-saved").textContent = earnedPaise ? fmtPaise(Math.abs(savedPaise)) : "-";
  $("#stat-saved").classList.toggle("neg", earnedPaise > 0 && savedPaise < 0);

  const fill = $("#hero-meter-fill");
  fill.className = "meter-fill " + (status.level === "warn" || status.level === "over" ? status.level : "");
  fill.style.width = Math.min(status.ratio, 1) * 100 + "%";

  const remainingEl = $("#stat-remaining");
  remainingEl.classList.remove("neg");

  if (budget) {
    const leftPaise = budget.limitPaise - spentPaise;
    $("#stat-budget").textContent = fmtPaise(budget.limitPaise);
    $("#stat-remaining-label").textContent = leftPaise < 0 ? "Exceeded By" : "Remaining";
    remainingEl.textContent = fmtPaise(Math.abs(leftPaise));
    if (leftPaise < 0) remainingEl.classList.add("neg");
    $("#hero-caption").textContent =
      Math.round(status.ratio * 100) + "% of monthly ceiling used" + (budget.carried ? " (carried from prior month)" : "") + ".";
  } else {
    $("#stat-budget").textContent = "Not set";
    $("#stat-remaining-label").textContent = "Remaining";
    remainingEl.textContent = "-";
    $("#hero-caption").textContent = "Configure a monthly budget to trigger pace alarms.";
  }

  renderBudgetAlert(spentPaise, budget, status);
  renderDailyChart(list, budget);

  const cats = totalsByCategory(list);
  const hasData = cats.length > 0;
  $("#cat-chart-wrap").hidden = !hasData;
  $("#category-legend").hidden = !hasData;
  $("#category-empty").hidden = hasData;

  if (hasData) {
    setChartDefaults();
    drawChart("category", "category-chart", "cat-chart-fallback", {
      type: "doughnut",
      data: {
        labels: cats.map(c => c.name),
        datasets: [{
          data: cats.map(c => c.totalPaise / 100),
          backgroundColor: cats.map(c => c.color),
          borderColor: "#101a2d",
          borderWidth: 3
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: "66%",
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: { label: ctx => " " + ctx.label + ": " + fmt(ctx.parsed) } }
        }
      }
    });

    $("#category-legend").innerHTML = cats.map(c =>
      '<li><span class="dot" style="background:' + c.color + '"></span>' +
      '<span class="name">' + c.name + '</span>' +
      '<span class="pct">' + Math.round(c.totalPaise / spentPaise * 100) + '%</span>' +
      '<span class="amt">' + fmtPaise(c.totalPaise) + '</span></li>'
    ).join("");
  }

  const recent = entriesInMonth(state.month).sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, 5);
  $("#recent-empty").hidden = recent.length > 0;
  $("#recent-list").innerHTML = recent.map(e => {
    const cat = categoryById(e.category);
    return '<li>' +
      '<span class="dot" style="background:' + cat.color + '"></span>' +
      '<div class="info"><div class="title">' + esc(e.note || cat.name) + '</div>' +
      '<div class="sub">' + cat.name + ' &middot; ' + formatDate(e.date) + '</div></div>' +
      '<span class="amt' + (isInc(e) ? ' inc' : '') + '">' + (isInc(e) ? '+' : '-') + fmtPaise(e.amountInPaise) + '</span>' +
      actionButtons(e.id) + '</li>';
  }).join("");
}

function renderDailyChart(list, budget) {
  $("#daily-panel").hidden = list.length === 0;
  if (!list.length) return;
  const [y, m] = state.month.split("-").map(Number);
  const days = new Date(y, m, 0).getDate();
  const now = new Date();
  const upto = state.month === monthKeyOf(now) ? now.getDate() : days;
  const perDayPaise = Array(days).fill(0);

  list.forEach(e => {
    const day = Number(e.date.slice(8, 10)) - 1;
    if (day >= 0 && day < days) perDayPaise[day] += e.amountInPaise;
  });

  let runPaise = 0;
  const cumulative = perDayPaise.map((v, i) => (i < upto ? (runPaise += v) / 100 : null));
  const datasets = [{
    label: "Spent to date",
    data: cumulative,
    borderColor: "#e6c15a",
    backgroundColor: "rgba(230,193,90,0.12)",
    fill: true,
    tension: 0.25,
    pointRadius: 0,
    borderWidth: 2.5
  }];

  if (budget) {
    datasets.push({
      label: "Budget Ceiling",
      data: Array(days).fill(budget.limitPaise / 100),
      borderColor: "#8fa0f0",
      borderDash: [6, 5],
      borderWidth: 2,
      pointRadius: 0
    });
  }

  setChartDefaults();
  drawChart("daily", "daily-chart", "daily-chart-fallback", {
    type: "line",
    data: { labels: Array.from({ length: days }, (_, i) => i + 1), datasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: "index", intersect: false },
      scales: {
        y: { beginAtZero: true, ticks: { callback: v => "\u20B9" + Number(v).toLocaleString("en-IN") } },
        x: { grid: { display: false } }
      },
      plugins: {
        legend: { position: "bottom", labels: { usePointStyle: true, boxWidth: 8 } },
        tooltip: { callbacks: { title: items => "Day " + items[0].label, label: ctx => " " + ctx.dataset.label + ": " + fmt(ctx.parsed.y) } }
      }
    }
  });
}

function renderBudgetAlert(spentPaise, budget, status) {
  const box = $("#budget-alert");
  box.className = "alert";

  if (status.level === "none") {
    box.classList.add("alert-info");
    box.innerHTML = '<span>No monthly budget defined. Establish a ceiling to track burn velocity.</span>' +
      '<button type="button" class="btn btn-ghost" data-action="goto" data-view="budget">Set Ceiling</button>';
    box.hidden = false;
  } else if (status.level === "warn") {
    box.classList.add("alert-warn");
    box.innerHTML = '<span><strong>Approaching Ceiling:</strong> Utilized ' + Math.round(status.ratio * 100) +
      '% of allowance. ' + fmtPaise(budget.limitPaise - spentPaise) + ' remaining.</span>';
    box.hidden = false;
  } else if (status.level === "over") {
    box.classList.add("alert-over");
    box.innerHTML = '<span><strong>Budget Breach:</strong> Over allowance by ' + fmtPaise(spentPaise - budget.limitPaise) +
      ' against ' + fmtPaise(budget.limitPaise) + ' ceiling.</span>';
    box.hidden = false;
  } else {
    box.hidden = true;
  }
}

/* ---------- History Table ---------- */
function getFilteredExpenses() {
  const cat = $("#f-category").value;
  const from = $("#f-from").value;
  const to = $("#f-to").value;
  const text = $("#f-search").value.trim().toLowerCase();

  return state.data.transactions
    .filter(e => !cat || e.category === cat)
    .filter(e => !from || e.date >= from)
    .filter(e => !to || e.date <= to)
    .filter(e => !text || (e.note || "").toLowerCase().includes(text))
    .sort((a, b) => (a.date < b.date ? 1 : -1));
}

function renderHistory() {
  const list = getFilteredExpenses();
  const total = state.data.transactions.length;
  const filtering = $("#f-category").value || $("#f-from").value || $("#f-to").value || $("#f-search").value.trim();

  const spentPaise = sumPaise(list.filter(e => !isInc(e)));
  const earnedPaise = sumPaise(list.filter(isInc));

  $("#history-summary").textContent = list.length
    ? `${list.length} records, Outflow: ${fmtPaise(spentPaise)}${earnedPaise ? ", Inflow: " + fmtPaise(earnedPaise) : ""}`
    : "";
  $("#export-btn").disabled = list.length === 0;

  $("#history-body").innerHTML = list.map(e => {
    const cat = categoryById(e.category);
    return '<tr>' +
      '<td class="date-cell">' + formatDate(e.date) + '</td>' +
      '<td><span class="chip"><span class="dot" style="background:' + cat.color + '"></span>' + cat.name + '</span></td>' +
      '<td class="note-cell" title="' + esc(e.note) + '">' + (e.note ? esc(e.note) : '<span class="muted">-</span>') + '</td>' +
      '<td class="num' + (isInc(e) ? ' inc' : '') + '">' + (isInc(e) ? '+' : '-') + fmtPaise(e.amountInPaise) + '</td>' +
      '<td>' + actionButtons(e.id) + '</td></tr>';
  }).join("");

  $(".table-wrap").hidden = list.length === 0;
  $("#history-empty").hidden = list.length > 0;
  $("#history-empty-text").textContent = total === 0
    ? "No entries logged yet. Record your first transaction or import a statement."
    : filtering ? "No transactions match specified filter parameters." : "No records found.";
}

function clearFilters() {
  $("#f-category").value = "";
  $("#f-from").value = "";
  $("#f-to").value = "";
  $("#f-search").value = "";
  renderHistory();
}

function exportCSV() {
  const list = getFilteredExpenses();
  const q = text => '"' + String(text || "").replace(/"/g, '""') + '"';
  const rows = [["Date", "Type", "Category", "Description", "Amount"].join(",")]
    .concat(list.map(e => [e.date, isInc(e) ? "Income" : "Expense", q(categoryById(e.category).name), q(e.note), (e.amountInPaise / 100).toFixed(2)].join(",")));

  const blob = new Blob([rows.join("\n")], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `spendwise-transactions-${state.month}.csv`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  toast("CSV statement exported successfully.", "success");
}

/* ---------- Reports ---------- */
function renderReports() {
  const list = expensesInMonth(state.month);
  const spentPaise = sumPaise(list);
  const cats = totalsByCategory(list);

  const months = [];
  for (let i = 5; i >= 0; i--) months.push(shiftMonth(state.month, -i));
  const totals = months.map(m => sumPaise(expensesInMonth(m)) / 100);
  const incomes = months.map(m => sumPaise(incomeInMonth(m)) / 100);
  const limits = months.map(m => { const b = getBudget(m); return b ? b.limitPaise / 100 : null; });

  setChartDefaults();
  drawChart("months", "month-chart", "month-chart-fallback", {
    type: "bar",
    data: {
      labels: months.map(m => formatMonth(m, true)),
      datasets: [
        {
          label: "Outflow",
          data: totals,
          backgroundColor: "rgba(230,193,90,0.85)",
          borderRadius: 6,
          maxBarThickness: 54
        },
        ...(incomes.some(Boolean) ? [{ label: "Inflow", data: incomes, backgroundColor: "rgba(95,201,160,0.7)", borderRadius: 6, maxBarThickness: 54 }] : []),
        {
          type: "line",
          label: "Budget Ceiling",
          data: limits,
          borderColor: "#8fa0f0",
          borderDash: [6, 5],
          borderWidth: 2,
          pointRadius: 0,
          spanGaps: true,
          stepped: true
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: { beginAtZero: true, ticks: { callback: v => "\u20B9" + Number(v).toLocaleString("en-IN") } },
        x: { grid: { display: false } }
      },
      plugins: {
        legend: { position: "bottom", labels: { usePointStyle: true, boxWidth: 8 } },
        tooltip: { callbacks: { label: ctx => " " + ctx.dataset.label + ": " + fmt(ctx.parsed.y) } }
      }
    }
  });

  $("#breakdown-empty").hidden = cats.length > 0;
  $("#breakdown-list").innerHTML = cats.map(c => {
    const pct = spentPaise > 0 ? Math.round(c.totalPaise / spentPaise * 100) : 0;
    return '<li><span class="dot" style="background:' + c.color + '"></span>' +
      '<span class="name">' + c.name + '</span>' +
      '<span class="amt">' + fmtPaise(c.totalPaise) + '</span>' +
      '<span class="pct">' + pct + '%</span>' +
      '<div class="bar"><span style="width:' + pct + '%;background:' + c.color + '"></span></div></li>';
  }).join("");

  const insights = $("#insights");
  if (list.length === 0) {
    insights.innerHTML = '<div><dt>No Activity</dt><dd><small>Log entries for this month to review analytical metrics.</small></dd></div>';
    return;
  }

  const [y, m] = state.month.split("-").map(Number);
  const now = new Date();
  const isCurrent = state.month === monthKeyOf(now);
  const daysCounted = isCurrent ? now.getDate() : new Date(y, m, 0).getDate();
  const earnedPaise = sumPaise(incomeInMonth(state.month));
  const biggest = [...list].sort((a, b) => b.amountInPaise - a.amountInPaise)[0];

  insights.innerHTML =
    '<div><dt>Primary Expenditure Category</dt><dd>' + cats[0].name + ' <small>' + fmtPaise(cats[0].totalPaise) + '</small></dd></div>' +
    '<div><dt>Average Daily Burn Rate</dt><dd>' + fmtPaise(Math.round(spentPaise / Math.max(daysCounted, 1))) + '</dd></div>' +
    '<div><dt>Largest Single Outflow</dt><dd>' + fmtPaise(biggest.amountInPaise) +
      ' <small>' + esc(biggest.note || categoryById(biggest.category).name) + '</small></dd></div>' +
    '<div><dt>Total Logged Entries</dt><dd>' + list.length + '</dd></div>' +
    (earnedPaise ? '<div><dt>Net Savings Rate</dt><dd>' + Math.max(0, Math.round((earnedPaise - spentPaise) / earnedPaise * 100)) + '% <small>of ' + fmtPaise(earnedPaise) + ' Inflow</small></dd></div>' : '');
}

/* ---------- Budget Management ---------- */
function renderBudget() {
  const month = state.month;
  const budgets = state.data.budgets;
  const exact = budgets[month];
  const budget = getBudget(month);
  const spentPaise = sumPaise(expensesInMonth(month));
  const status = budgetStatus(spentPaise, budget);

  $("#budget-title").textContent = "Ceiling Allocation: " + formatMonth(month);
  $("#budget-input").value = exact != null ? (exact / 100).toFixed(0) : "";
  $("#budget-error").textContent = "";
  $("#budget-remove").hidden = exact == null;

  const box = $("#budget-status");
  if (!budget) {
    box.innerHTML = '<p class="muted">No explicit ceiling defined for this month.</p>';
  } else {
    const label = status.level === "over" ? "Limit Breached" : status.level === "warn" ? "Approaching Limit" : "Nominal";
    const leftPaise = budget.limitPaise - spentPaise;
    box.innerHTML =
      '<p><span class="badge ' + status.level + '">' + label + '</span></p>' +
      '<div class="meter"><div class="meter-fill ' + (status.level === "ok" ? "" : status.level) +
        '" style="width:' + Math.min(status.ratio, 1) * 100 + '%"></div><span class="meter-tick"></span></div>' +
      '<p class="meter-caption">' + fmtPaise(spentPaise) + ' of ' + fmtPaise(budget.limitPaise) + ' (' + Math.round(status.ratio * 100) + '%). ' +
      (leftPaise >= 0 ? fmtPaise(leftPaise) + ' remaining.' : fmtPaise(-leftPaise) + ' over ceiling.') +
      (budget.carried ? ' (Ceiling carried forward from prior configuration)' : '') + '</p>';
  }

  const keys = Object.keys(budgets).sort().reverse();
  $("#budget-empty").hidden = keys.length > 0;
  $("#budget-list").innerHTML = keys.map(k => {
    const s = sumPaise(expensesInMonth(k));
    const st = budgetStatus(s, { limitPaise: budgets[k] });
    const text = st.level === "over" ? "Over" : st.level === "warn" ? "Warning" : "On track";
    return '<li><span class="month">' + formatMonth(k) + '</span>' +
      '<span class="detail">' + fmtPaise(s) + ' / ' + fmtPaise(budgets[k]) + '</span>' +
      '<span class="badge ' + st.level + '">' + text + '</span></li>';
  }).join("");
}

function onSaveBudget(e) {
  e.preventDefault();
  const value = parseFloat($("#budget-input").value);

  if (!(value > 0)) {
    $("#budget-error").textContent = "Enter a valid amount greater than 0.";
    return;
  }

  state.data.budgets[state.month] = Math.round(value * 100);
  saveTenantData();
  renderCurrentView();
  toast("Monthly budget established for " + formatMonth(state.month) + ".", "success");
}

function onRemoveBudget() {
  if (!confirm("Remove the budget configuration for " + formatMonth(state.month) + "?")) return;
  delete state.data.budgets[state.month];
  saveTenantData();
  renderCurrentView();
  toast("Budget allocation removed.", "info");
}

/* ---------- Goals Management ---------- */
function renderGoals() {
  const goals = state.data.goals;
  $("#goal-empty").hidden = goals.length > 0;
  $("#goal-list").innerHTML = goals.map(g => {
    const ratio = Math.min(g.savedPaise / g.targetPaise, 1);
    const done = g.savedPaise >= g.targetPaise;
    let hint = "";
    if (!done && g.date) {
      const now = new Date(), end = parseISO(g.date);
      const months = Math.max(1, (end.getFullYear() - now.getFullYear()) * 12 + end.getMonth() - now.getMonth());
      hint = end < now ? " Target deadline has passed." : " Allocate approx. " + fmtPaise(Math.ceil((g.targetPaise - g.savedPaise) / months)) + "/mo to meet target.";
    }
    return '<li><div class="goal-head"><span class="goal-name">' + esc(g.name) + '</span>' +
      (done ? '<span class="badge ok">Fulfilled</span>' : '<span class="muted">' + Math.round(ratio * 100) + '%</span>') + '</div>' +
      '<div class="meter"><div class="meter-fill' + (done ? ' done' : '') + '" style="width:' + ratio * 100 + '%"></div></div>' +
      '<p class="meter-caption">' + fmtPaise(g.savedPaise) + ' of ' + fmtPaise(g.targetPaise) + '.' + hint + '</p>' +
      '<div class="goal-add"><input type="number" min="1" step="1" placeholder="Allocate Funds (&#8377;)" aria-label="Amount to fund ' + esc(g.name) + '">' +
      '<button type="button" class="btn btn-ghost" data-action="goal-add" data-id="' + g.id + '">Fund</button>' +
      '<button type="button" class="link-btn" data-action="goal-del" data-id="' + g.id + '">Delete</button></div></li>';
  }).join("");
}

function onSaveGoal(e) {
  e.preventDefault();
  const name = $("#goal-name").value.trim();
  const target = parseFloat($("#goal-target").value);
  const date = $("#goal-date").value;
  const err = $("#goal-error");
  if (!name) return void (err.textContent = "Specify a goal description.");
  if (!(target > 0)) return void (err.textContent = "Target amount must exceed 0.");
  if (date && (!isValidDate(date) || date <= todayISO())) return void (err.textContent = "Target date must be in the future.");

  state.data.goals.push({
    id: uid(),
    name,
    targetPaise: Math.round(target * 100),
    savedPaise: 0,
    date
  });
  err.textContent = "";
  $("#goal-form").reset();
  saveTenantData();
  renderGoals();
  toast("Savings goal initialized.", "success");
}

function addToGoal(btn) {
  const g = state.data.goals.find(x => x.id === btn.dataset.id);
  const input = btn.parentElement.querySelector("input");
  const amt = parseFloat(input.value);
  if (!g || !(amt > 0)) return toast("Specify an allocation greater than 0.", "warn");

  const wasDone = g.savedPaise >= g.targetPaise;
  g.savedPaise += Math.round(amt * 100);
  input.value = "";
  saveTenantData();
  renderGoals();
  toast(!wasDone && g.savedPaise >= g.targetPaise ? "Goal Reached: " + g.name + "!" : "Allocated to " + g.name + ".", "success");
}

function deleteGoal(id) {
  const g = state.data.goals.find(x => x.id === id);
  if (!g || !confirm(`Delete savings goal "${g.name}"?`)) return;
  state.data.goals = state.data.goals.filter(x => x.id !== id);
  saveTenantData();
  renderGoals();
  toast("Goal removed.", "info");
}

/* ---------------------------------------------------------
   SAMPLE DATA GENERATION (DEMO TENANT)
   --------------------------------------------------------- */
function generateSampleData(tenantId) {
  const templates = [
    ["food",          60,  480, ["Canteen meal", "Groceries", "Dinner with peers", "Tea and snacks", "Hostel breakfast"], 5],
    ["travel",        30,  650, ["Auto ride", "Metro commute", "Bus fare", "Station cab"], 3],
    ["shopping",     300, 2400, ["T-shirt", "Headphones", "Backpack", "Running shoes"], 1.2],
    ["bills",        199, 1100, ["Mobile recharge", "Wi-Fi split", "Hostel electricity share"], 1],
    ["entertainment",100,  700, ["Movie ticket", "OTT renewal", "Gaming pass"], 1],
    ["health",       100,  900, ["Pharmacy prescription", "Gym subscription"], 0.6],
    ["education",    150, 1500, ["Notebooks & pens", "Online technical course", "Printouts", "Lab record binder"], 0.9],
    ["other",         50,  400, ["Gift item", "Stationery sundries"], 0.6]
  ];
  const totalWeight = templates.reduce((t, x) => t + x[4], 0);

  let seed = 19;
  const rnd = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;

  const today = new Date();
  const transactions = [];
  const perMonthPaise = {};

  for (let back = 0; back < 4; back++) {
    const first = new Date(today.getFullYear(), today.getMonth() - back, 1);
    const key = monthKeyOf(first);
    const lastDay = back === 0 ? today.getDate() : new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate();
    const count = back === 0 ? Math.max(6, Math.round(lastDay * 0.9)) : 22;
    perMonthPaise[key] = 0;

    for (let i = 0; i < count; i++) {
      let pick = rnd() * totalWeight;
      let tpl = templates[0];
      for (const t of templates) { pick -= t[4]; if (pick <= 0) { tpl = t; break; } }

      const rawAmount = Math.round((tpl[1] + rnd() * (tpl[2] - tpl[1])) / 5) * 5;
      const amountInPaise = rawAmount * 100;
      const day = 1 + Math.floor(rnd() * lastDay);
      const note = tpl[3][Math.floor(rnd() * tpl[3].length)];
      const date = toISO(new Date(first.getFullYear(), first.getMonth(), day));

      transactions.push({
        id: uid() + "_" + i + back,
        tenantId,
        amountInPaise,
        category: tpl[0],
        date,
        note,
        type: "expense",
        fingerprint: `fp_${tenantId}_${date}_${amountInPaise}_${note}`
      });
      perMonthPaise[key] += amountInPaise;
    }
  }

  for (let back = 0; back < 4; back++) {
    const first = new Date(today.getFullYear(), today.getMonth() - back, 1);
    transactions.push({
      id: uid() + "_inc_" + back,
      tenantId,
      amountInPaise: 1200000,
      category: "income",
      type: "income",
      date: toISO(first),
      note: "Monthly Allowance",
      fingerprint: `fp_${tenantId}_${toISO(first)}_1200000_Monthly Allowance`
    });
  }

  const budgets = {};
  const ratios = [0.83, 0.74, 1.05, 0.88];
  Object.keys(perMonthPaise).forEach((key, i) => {
    budgets[key] = Math.ceil((perMonthPaise[key] / ratios[i]) / 10000) * 10000;
  });

  const goals = [
    { id: uid() + "_g1", name: "Laptop Upgrade", targetPaise: 5500000, savedPaise: 2200000, date: toISO(new Date(today.getFullYear(), today.getMonth() + 6, 1)) },
    { id: uid() + "_g2", name: "Winter Tour", targetPaise: 1500000, savedPaise: 950000, date: "" }
  ];

  return { transactions, budgets, goals };
}

/* ---------------------------------------------------------
   INITIALIZATION & EVENT BINDINGS
   --------------------------------------------------------- */
function init() {
  const options = CATEGORIES.map(c => '<option value="' + c.id + '">' + c.name + '</option>').join("");
  $("#expense-category").innerHTML = options;
  $("#f-category").insertAdjacentHTML("beforeend", options);

  $$(".tab").forEach(tab => tab.addEventListener("click", () => switchAuthTab(tab.dataset.tab)));
  $("#login-form").addEventListener("submit", onLogin);
  $("#register-form").addEventListener("submit", onRegister);
  $("#demo-btn").addEventListener("click", onDemo);
  $("#logout-btn").addEventListener("click", logout);

  $$(".nav-btn").forEach(btn => btn.addEventListener("click", () => showView(btn.dataset.view)));
  $("#prev-month").addEventListener("click", () => { state.month = shiftMonth(state.month, -1); renderCurrentView(); });
  $("#next-month").addEventListener("click", () => { state.month = shiftMonth(state.month, 1); renderCurrentView(); });

  $("#add-btn").addEventListener("click", () => openExpenseModal());
  $("#expense-form").addEventListener("submit", onSaveExpense);
  $("#modal-close").addEventListener("click", closeExpenseModal);
  $("#modal-cancel").addEventListener("click", closeExpenseModal);
  modal().addEventListener("click", e => { if (e.target === modal()) closeExpenseModal(); });

  ["f-category", "f-from", "f-to"].forEach(id => $("#" + id).addEventListener("change", renderHistory));
  $("#f-search").addEventListener("input", renderHistory);
  $("#clear-filters").addEventListener("click", clearFilters);
  $("#export-btn").addEventListener("click", exportCSV);

  const fileInput = $("#csv-file-input");
  $("#trigger-csv-btn").addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", (e) => {
    if (e.target.files && e.target.files[0]) {
      processCSVFile(e.target.files[0]);
    }
  });

  $("#budget-form").addEventListener("submit", onSaveBudget);
  $("#budget-remove").addEventListener("click", onRemoveBudget);

  $$(".seg-btn").forEach(b => b.addEventListener("click", () => setEntryType(b.dataset.type)));
  $("#goal-form").addEventListener("submit", onSaveGoal);

  $$('input[type="password"]').forEach(input => {
    const wrap = document.createElement("div");
    wrap.className = "pw-wrap";
    input.parentNode.insertBefore(wrap, input);
    wrap.appendChild(input);
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "pw-toggle";
    btn.textContent = "Show";
    btn.setAttribute("aria-label", "Toggle password visibility");
    btn.addEventListener("click", () => {
      const show = input.type === "password";
      input.type = show ? "text" : "password";
      btn.textContent = show ? "Hide" : "Show";
    });
    wrap.appendChild(btn);
  });

  document.addEventListener("keydown", e => {
    if (e.key.toLowerCase() !== "n" || e.ctrlKey || e.metaKey || e.altKey) return;
    if (!state.user || modal().open || /INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
    e.preventDefault();
    openExpenseModal();
  });

  document.addEventListener("click", e => {
    const btn = e.target.closest("[data-action]");
    if (!btn) return;
    const action = btn.dataset.action;
    if (action === "edit") openExpenseModal(btn.dataset.id);
    if (action === "delete") deleteExpense(btn.dataset.id);
    if (action === "add") openExpenseModal();
    if (action === "goto") showView(btn.dataset.view);
    if (action === "goal-add") addToGoal(btn);
    if (action === "goal-del") deleteGoal(btn.dataset.id);
  });

  const sessionId = loadJSON(KEYS.session, null);
  const user = sessionId ? getUsers().find(u => u.id === sessionId) : null;
  if (user) startSession(user);
}

document.addEventListener("DOMContentLoaded", init);
