# SpendWise

A personal expense tracker that runs entirely in the browser. It lets a signed-in user record income and expenses, sort them into categories, set monthly budgets and savings goals, and see where the money goes on a dashboard and in reports.

Live demo: https://spendwiserss.netlify.app/

## Features

- **Accounts:** sign up, log in and log out. Each user gets their own separate data store. A "Try with sample student data" button loads a demo account.
- **Transactions:** add, edit and delete income and expenses, with validation (amount must be above zero, date must be valid and not in the future).
- **Automatic categories:** keywords in the description (for example "swiggy", "uber", "netflix") suggest one of eight categories. The rules are plain regular expressions, so they are easy to read and change.
- **Dashboard:** spent this month, budget progress with an 80% warning marker, income and net balance, a cumulative spending chart, a category doughnut chart and recent activity.
- **History:** filter by category, date range and text search, and export the result as CSV.
- **Reports:** a six-month trend chart, category breakdown and key figures such as average daily spend and largest single expense.
- **Budgets:** a monthly limit with alerts at 80% and 100%, and a history of past months.
- **Goals:** savings targets with progress and a suggested monthly amount.
- **CSV import:** detects the Date, Amount, Description and Category columns, skips malformed rows and drops duplicates using a SHA-256 fingerprint.
- **Accurate money maths:** amounts are stored as whole paise, so there is no floating-point drift.

## Tech stack

- HTML5, CSS3 and vanilla JavaScript (ES6+), with no build step
- [Chart.js 4.4.1](https://www.chartjs.org/) loaded from cdnjs with an integrity hash
- Google Fonts (Playfair Display and Space Grotesk)
- Browser `localStorage` for data and the Web Crypto API for hashing

## Project structure

```
index.html   page structure: sign-in screen, app views, transaction dialog
style.css    styling (dark navy background with gold accents, responsive layout)
app.js       all application logic
```

## Run it locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox or Safari).

An internet connection is needed for Chart.js and the fonts. If Chart.js cannot load, the charts show a short fallback message and everything else still works.

## Important notes

- All data is stored in the browser's `localStorage` on the device in use. There is no server or database, so clearing site data deletes everything and data does not sync between devices.
- Passwords are hashed with SHA-256 in the browser before they are saved. This keeps plain-text passwords out of storage, but it is demo-level security, not a replacement for server-side authentication.
- Automatic categorisation uses fixed keyword rules, not a trained model.

## Author

PLACEHOLDER (add your name, course and college)
